### Software Design Labs (BSUIR, FCSN)

| Number | Summary | Description |
| ------ | ------ | ------ |
| 1 | Environment & project setup | [Description](https://github.com/gmltA/SoftwareDesign_tasks#1-environment--project-setup) |  
| 2 | Activities, fragments and navigation | [Description](https://github.com/gmltA/SoftwareDesign_tasks#2-activities-fragments-and-navigation) |
